angular.module('mapboxgl-directive').factory('FloorplansManagerAlt', ['Utils', 'mapboxglConstants', '$rootScope', '$compile', '$timeout', function (Utils, mapboxglConstants, $rootScope, $compile, $timeout) {
  function FloorplansManagerAlt (mapInstance) {
    this.floorplansCreated = [];
    this.markersCreated = [];
    this.mapInstance = mapInstance;
  }

  /**
   * Conserve aspect ratio of the original region. Useful when shrinking/enlarging
   * images to fit into a certain area.
   *
   * @param {Number} srcWidth width of source image
   * @param {Number} srcHeight height of source image
   * @param {Number} maxWidth maximum available width
   * @param {Number} maxHeight maximum available height
   * @return {Object} { width, height }
   */
  function calculateAspectRatioFit(srcWidth, srcHeight, maxWidth, maxHeight) {

    var ratio = Math.min(maxWidth / srcWidth, maxHeight / srcHeight);

    return { width: srcWidth*ratio, height: srcHeight*ratio, ratio: ratio };
  }

  FloorplansManagerAlt.prototype.createFloorplanByObject = function (object, drawInstance) {
    Utils.checkObjects([
      {
        name: 'Map',
        object: this.mapInstance
      }, {
        name: 'Object',
        object: object,
        attributes: ['coordinates', 'url', 'id', 'scale', 'angle', 'opacity', 'center']
      }
    ]);

    var self = this;
    var elementId = object.id;
    elementId = angular.isDefined(elementId) && elementId !== null ? elementId : Utils.generateGUID();
    var scope = $rootScope.$new();  // or $new(true) if you want an isolate scope

    object.id = elementId;

    const id = 'floorplan-'+elementId;
    const sourceId = 'floorplan-source-'+elementId;

    const map = this.mapInstance;

    var img = new Image();
    img.src = object.url;
    img.onload = function() {
      const image_size = calculateAspectRatioFit(this.width, this.height, map._container.clientWidth, map._container.clientHeight);
      const original_ratio = image_size.ratio;
      const map_bounds = map.getBounds();
      const map_center = map.getCenter();
      const map_top_center = {
        lat: map_bounds._ne.lat,
        lng: map_center.lng
      };

      const from = turf.point([map_center.lng, map_center.lat]);
      const to = turf.point([map_top_center.lng, map_top_center.lat]);
      const distance = turf.distance(from, to);

      const image_height_km = distance*2;
      const image_width_km = (image_size.width / image_size.height) * image_height_km;
      const ne_corner = turf.destination(to, image_width_km / 2, -90);
      const nw_corner = turf.destination(ne_corner, image_width_km, 90);
      const sw_corner = turf.destination(nw_corner, image_height_km, 180);
      const se_corner = turf.destination(sw_corner, image_width_km, -90);

      var c,
          c_scaled,
          c_rotated,
          c_org,
          floorplan_holder,
          floorplan_holder_scaled,
          floorplan_holder_rotated,
          floorplan_holder_org,
          scale_ratio,
          angle,
          opacity,
          center,
          dragging = false;
      if (object.coordinates) {
        c = object.coordinates;
        floorplan_holder = turf.polygon([[c[0], c[1], c[2], c[3], c[0]]]);
        center = turf.centroid(floorplan_holder).geometry.coordinates;
        scale_ratio = object.scale/100;
        opacity = object.opacity ? object.opacity : 65;
      } else {
        c = [ne_corner.geometry.coordinates, nw_corner.geometry.coordinates, sw_corner.geometry.coordinates, se_corner.geometry.coordinates];
        floorplan_holder = turf.polygon([[c[0], c[1], c[2], c[3], c[0]]]);
        floorplan_holder = turf.transformScale(floorplan_holder, 0.75);
        floorplan_holder_scaled = angular.copy(floorplan_holder); // keep original angle but variable scale and position
        floorplan_holder_rotated = angular.copy(floorplan_holder); // keep original scale but variable angle and position
        floorplan_holder_org = angular.copy(floorplan_holder); // non scaled and non rotated but variable position
        center = turf.centroid(floorplan_holder).geometry.coordinates;
        c = [floorplan_holder.geometry.coordinates[0][0], floorplan_holder.geometry.coordinates[0][1], floorplan_holder.geometry.coordinates[0][2], floorplan_holder.geometry.coordinates[0][3]];
        // keeps original angle but variable scale and position coordinates
        c_scaled = [
          floorplan_holder_scaled.geometry.coordinates[0][0],
          floorplan_holder_scaled.geometry.coordinates[0][1],
          floorplan_holder_scaled.geometry.coordinates[0][2],
          floorplan_holder_scaled.geometry.coordinates[0][3]
        ];
        // keeps original scale but variable angle and position coordinates
        c_rotated = [
          floorplan_holder_rotated.geometry.coordinates[0][0],
          floorplan_holder_rotated.geometry.coordinates[0][1],
          floorplan_holder_rotated.geometry.coordinates[0][2],
          floorplan_holder_rotated.geometry.coordinates[0][3]
        ];
        // non scaled and non rotated but variable position coordinates
        c_org = [
          floorplan_holder_org.geometry.coordinates[0][0],
          floorplan_holder_org.geometry.coordinates[0][1],
          floorplan_holder_org.geometry.coordinates[0][2],
          floorplan_holder_org.geometry.coordinates[0][3]
        ];
        scale_ratio = 1;
        opacity = object.opacity ? object.opacity : 65;
      }

      $timeout(function() {
        object.scale = scale_ratio*100;
        object.angle = object.angle ? object.angle : 0;
        object.opacity = opacity;
        object.coordinates = c;
        object.center = {
          lat: center[1],
          lng: center[0]
        };
      });

      const options = {
        type: 'image',
        url: object.url,
        coordinates: [floorplan_holder.geometry.coordinates[0][0], floorplan_holder.geometry.coordinates[0][1], floorplan_holder.geometry.coordinates[0][2], floorplan_holder.geometry.coordinates[0][3]]
      };

      map.addSource(sourceId, options);

      map.addLayer({
        id: id,
        source: sourceId,
        type: 'raster',
        layout: {
          'visibility': object.visible ? 'visible' : 'none'
        },
        paint: {
          "raster-opacity": opacity/100
        }
      }, 'country_label_1');

      /*map.addSource('my-geojson', {
          "type": "geojson",
          "data": floorplan_holder_scaled
      });
      map.addSource('my-geojson2', {
          "type": "geojson",
          "data": floorplan_holder_rotated
      });

      map.addLayer({
          "id": "geojsonLayer",
          "type": "fill",
          "source": "my-geojson",
          "paint": {
            "fill-color": "#000fff",
            "fill-opacity": 0.65
          }
      });
      map.addLayer({
          "id": "geojsonLayer2",
          "type": "fill",
          "source": "my-geojson2",
          "paint": {
            "fill-color": "#ff1439",
            "fill-opacity": 0.65
          }
      });*/

      self.floorplansCreated.push({
        id: id,
        sourceId: sourceId,
        mapInstance: map
      });

      var floorplanSource = map.getSource(sourceId);
      //var geojsonSource = map.getSource('my-geojson');
      //var geojsonSource2 = map.getSource('my-geojson2');

      function move(e, floorplan) {
        const fresh = c.map(function(val){
          return e ?
            [val[0] - (center[0] - e.target._lngLat.lng), val[1] - (center[1] - e.target._lngLat.lat)] :
            [val[0] - (center[0] - floorplan.center.lng), val[1] - (center[1] - floorplan.center.lat)];
        });
        const scaled = c_scaled.map(function(val){
          return e ?
            [val[0] - (center[0] - e.target._lngLat.lng), val[1] - (center[1] - e.target._lngLat.lat)] :
            [val[0] - (center[0] - floorplan.center.lng), val[1] - (center[1] - floorplan.center.lat)];
        });
        const rotated = c_rotated.map(function(val){
          return e ?
            [val[0] - (center[0] - e.target._lngLat.lng), val[1] - (center[1] - e.target._lngLat.lat)] :
            [val[0] - (center[0] - floorplan.center.lng), val[1] - (center[1] - floorplan.center.lat)];
        });
        const original = c_org.map(function(val){
          return e ?
            [val[0] - (center[0] - e.target._lngLat.lng), val[1] - (center[1] - e.target._lngLat.lat)] :
            [val[0] - (center[0] - floorplan.center.lng), val[1] - (center[1] - floorplan.center.lat)];
        });
        $timeout(function() {
          object.center = e ? e.target._lngLat : floorplan.center;
        });
        return {
          event: 'move',
          fresh: fresh,
          scaled: scaled,
          rotated: rotated,
          original: original
        };
      }

      function scale(e, startPosition, floorplan) {
        if (e) {
          var diagonal = turf.distance(c[0], c[2]);
          var distance = turf.distance([startPosition._lngLat.lng, startPosition._lngLat.lat], [e.target._lngLat.lng, e.target._lngLat.lat]);
          var centerPosition = self.markersCreated[0]._pos;
          var isOnRight = e.target._pos.x > centerPosition.x;
          var goesLeft = e.target._pos.x < startPosition._pos.x;
          var expanding = (isOnRight && !goesLeft) || (!isOnRight && goesLeft);
        }
        var scale_by = e ?
          expanding ? 1+((distance/diagonal)*2) : 1-((distance/diagonal)*2) :
          scale_ratio < floorplan.scale/100 ? floorplan.scale/100 : floorplan.scale/100;
        $timeout(function() {
          object.scale = e ? (scale_ratio*scale_by)*100 : floorplan.scale;
        });
        var scaledPoly = turf.transformScale(e ? floorplan_holder : floorplan_holder_rotated, scale_by ? scale_by : 1);
        var scaledPoly_org = turf.transformScale(e ? floorplan_holder_scaled : floorplan_holder_org, scale_by ? scale_by : 1);
        return {
          event: 'scale',
          fresh: [scaledPoly.geometry.coordinates[0][0], scaledPoly.geometry.coordinates[0][1], scaledPoly.geometry.coordinates[0][2], scaledPoly.geometry.coordinates[0][3]],
          scaled: [scaledPoly_org.geometry.coordinates[0][0], scaledPoly_org.geometry.coordinates[0][1], scaledPoly_org.geometry.coordinates[0][2], scaledPoly_org.geometry.coordinates[0][3]]
        };
      }

      function rotate(e, startPosition, floorplan) {
        if (e) {
          var centroid = turf.centroid(floorplan_holder);
          var draggedBearing = turf.bearing(centroid, [e.target._lngLat.lng, e.target._lngLat.lat]);
          var bearingFromCenter = turf.bearing(centroid, [startPosition._lngLat.lng, startPosition._lngLat.lat]);
        }
        var rotate_by = e ?
          draggedBearing-bearingFromCenter :
          floorplan.angle;
        $timeout(function() {
          object.angle = e ? angle+(draggedBearing-bearingFromCenter) : floorplan.angle;
        });
        var scaledPoly = turf.transformRotate(e ? floorplan_holder : floorplan_holder_scaled, rotate_by ? rotate_by : 0);
        var scaledPoly_org = turf.transformRotate(e ? floorplan_holder_rotated : floorplan_holder_org, rotate_by ? rotate_by : 0);
        return {
          event: 'rotate',
          fresh: [scaledPoly.geometry.coordinates[0][0], scaledPoly.geometry.coordinates[0][1], scaledPoly.geometry.coordinates[0][2], scaledPoly.geometry.coordinates[0][3]],
          rotated: [scaledPoly_org.geometry.coordinates[0][0], scaledPoly_org.geometry.coordinates[0][1], scaledPoly_org.geometry.coordinates[0][2], scaledPoly_org.geometry.coordinates[0][3]]
        };
      }

      scope.$on('center-change', function(args, floorplan) {
        if (!dragging) {
          console.log('center-change');
          var new_coordinates = move(null, floorplan);
          applyChanges(new_coordinates);
        }
      });

      scope.$on('scale-change', function(args, floorplan) {
        if (!dragging) {
          console.log('scale-change');
          var new_coordinates = scale(null, null, floorplan);
          applyChanges(new_coordinates);
        }
      });

      scope.$on('angle-change', function(args, floorplan) {
        if (!dragging) {
          console.log('angle-change');
          var new_coordinates = rotate(null, null, floorplan);
          applyChanges(new_coordinates);
        }
      });

      function applyChanges(new_coordinates) {
        if (new_coordinates) {
          floorplanSource.setCoordinates(new_coordinates.fresh);
          angular.forEach(self.markersCreated, function(marker, key) {
            if (marker._element.id !== 'move-marker') {
              marker.setLngLat(new_coordinates.fresh[key-1]);
            }
          });
          c = new_coordinates.fresh;
          floorplan_holder = turf.polygon([[c[0], c[1], c[2], c[3], c[0]]]);
          if (new_coordinates.event === 'move') {
            c_scaled = new_coordinates.scaled ? new_coordinates.scaled : c_scaled;
            c_rotated = new_coordinates.rotated ? new_coordinates.rotated : c_rotated;
            c_org = new_coordinates.original ? new_coordinates.original : c_org;
            floorplan_holder_scaled = turf.polygon([[c_scaled[0], c_scaled[1], c_scaled[2], c_scaled[3], c_scaled[0]]]);
            floorplan_holder_rotated = turf.polygon([[c_rotated[0], c_rotated[1], c_rotated[2], c_rotated[3], c_rotated[0]]]);
            floorplan_holder_org = turf.polygon([[c_org[0], c_org[1], c_org[2], c_org[3], c_org[0]]]);
            center = [object.center.lng, object.center.lat];
            self.markersCreated[0].setLngLat(center);
          } else if (new_coordinates.event === 'scale') {
            c_scaled = new_coordinates.scaled ? new_coordinates.scaled : c_scaled;
            floorplan_holder_scaled = turf.polygon([[c_scaled[0], c_scaled[1], c_scaled[2], c_scaled[3], c_scaled[0]]]);
          } else if (new_coordinates.event === 'rotate') {
            c_rotated = new_coordinates.rotated ? new_coordinates.rotated : c_rotated;
            floorplan_holder_rotated = turf.polygon([[c_rotated[0], c_rotated[1], c_rotated[2], c_rotated[3], c_rotated[0]]]);
          }
          //geojsonSource.setData(floorplan_holder_scaled);
          //geojsonSource2.setData(floorplan_holder_rotated);
          scale_ratio = object.scale/100;
          angle = object.angle;
          $timeout(function() {
            object.coordinates = c;
          });
        }
      }

      scope.$on('opacity-change', function(args, floorplan) {
        map.setPaintProperty(id, 'raster-opacity', floorplan.opacity/100);
        opacity = floorplan.opacity;
      });

      if (object.editable) {
        var startPosition;
        var markers = [{
          type: 'move-marker',
          icon: 'move-marker',
          position: [center[0], center[1]]
        }, {
          type: 'rotate-marker-ne',
          icon: 'rotate-marker',
          position: floorplan_holder.geometry.coordinates[0][0]
        }, {
          type: 'scale-marker-nw',
          icon: 'scale-marker',
          position: floorplan_holder.geometry.coordinates[0][1]
        }, {
          type: 'rotate-marker-sw',
          icon: 'rotate-marker',
          position: floorplan_holder.geometry.coordinates[0][2]
        }, {
          type: 'scale-marker-se',
          icon: 'scale-marker',
          position: floorplan_holder.geometry.coordinates[0][3]
        }];

        angular.forEach(markers, function(marker) {
          var el = document.createElement('div');
          el.id = marker.type;
          el.className = 'marker ' + marker.type;
          el.style.backgroundImage = 'url(lib/images/'+marker.icon+'.png)';
          el.style.width = '32px';
          el.style.height = '32px';

          // add marker to map
          var m = new mapboxgl.Marker({
            id: marker.type,
            draggable: true,
            element: el
          })
            .setLngLat(marker.position)
            .addTo(map);

          m.on('dragstart', function(e) {
            startPosition = {
              _lngLat: e.target._lngLat,
              _pos: e.target._pos
            };
            map.setPaintProperty(id, 'raster-opacity', 0.3);
          });

          var new_coordinates;
          m.on('drag', function(e) {
            dragging = true;
            if (marker.type === 'move-marker') {
              new_coordinates = move(e);
            } else if (marker.icon === 'scale-marker') {
              new_coordinates = scale(e, startPosition);
            } else if (marker.icon === 'rotate-marker') {
              new_coordinates = rotate(e, startPosition);
            }
            if (new_coordinates.fresh) {
              floorplanSource.setCoordinates(new_coordinates.fresh);
              angular.forEach(self.markersCreated, function(marker, key) {
                if (marker._element.id !== 'move-marker') {
                  marker.setLngLat(new_coordinates.fresh[key-1]);
                }
              });
            }
          });

          m.on('dragend', function(e) {
            dragging = false;
            if (marker.type === 'move-marker') {
              center = [e.target._lngLat.lng, e.target._lngLat.lat];
            }
            c = new_coordinates.fresh;
            floorplan_holder = turf.polygon([[c[0], c[1], c[2], c[3], c[0]]]);
            if (new_coordinates.event === 'move') {
              c_scaled = new_coordinates.scaled ? new_coordinates.scaled : c_scaled;
              c_rotated = new_coordinates.rotated ? new_coordinates.rotated : c_rotated;
              c_org = new_coordinates.original ? new_coordinates.original : c_org;
              floorplan_holder_scaled = turf.polygon([[c_scaled[0], c_scaled[1], c_scaled[2], c_scaled[3], c_scaled[0]]]);
              floorplan_holder_rotated = turf.polygon([[c_rotated[0], c_rotated[1], c_rotated[2], c_rotated[3], c_rotated[0]]]);
              floorplan_holder_org = turf.polygon([[c_org[0], c_org[1], c_org[2], c_org[3], c_org[0]]]);
            } else if (new_coordinates.event === 'scale') {
              c_scaled = new_coordinates.scaled ? new_coordinates.scaled : c_scaled;
              floorplan_holder_scaled = turf.polygon([[c_scaled[0], c_scaled[1], c_scaled[2], c_scaled[3], c_scaled[0]]]);
            } else if (new_coordinates.event === 'rotate') {
              c_rotated = new_coordinates.rotated ? new_coordinates.rotated : c_rotated;
              floorplan_holder_rotated = turf.polygon([[c_rotated[0], c_rotated[1], c_rotated[2], c_rotated[3], c_rotated[0]]]);
            }
            //geojsonSource.setData(floorplan_holder_scaled);
            //geojsonSource2.setData(floorplan_holder_rotated);
            scale_ratio = object.scale/100;
            angle = object.angle;
            $timeout(function() {
              object.coordinates = c;
            });
            map.setPaintProperty(id, 'raster-opacity', opacity/100);
          });

          self.markersCreated.push(m);
        });
      }
    };

  };

  FloorplansManagerAlt.prototype.removeAllFloorplansCreated = function () {
    this.floorplansCreated.map(function (eachFloorplan) {
      if (eachFloorplan.mapInstance.getLayer(eachFloorplan.id)) {
        eachFloorplan.mapInstance.removeLayer(eachFloorplan.id);
      }
      if (eachFloorplan.mapInstance.getSource(eachFloorplan.sourceId)) {
        eachFloorplan.mapInstance.removeSource(eachFloorplan.sourceId);
      }
    });

    if (this.markersCreated.length > 0) {
      angular.forEach(this.markersCreated, function(marker){
        marker.remove();
      });
    }

    this.floorplansCreated = [];
    this.markersCreated = [];
  };

  return FloorplansManagerAlt;
}]);
